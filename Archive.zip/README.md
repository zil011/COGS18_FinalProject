# COGS18_FinalProject
Final project for COGS18, taught by professor Ellis in Spring 19, at UCSD
